# jellypy-tierup

Reanalyse Tier3 variants. TierUp finds tier 3 variants in PanelApp green genes.

https://acgs.gitbook.io/jellypy/tierup

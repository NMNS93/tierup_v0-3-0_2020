auth_credentials = None
